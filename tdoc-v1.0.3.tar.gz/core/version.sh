#!/data/data/com.termux/files/usr/bin/env bash

export TDOC_NAME="TDOC (Termux Doctor)"
export TDOC_VERSION="1.0.3"
export TDOC_CODENAME="Aurora"
export TDOC_BUILD_DATE="$(date -I)"
